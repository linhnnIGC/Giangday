import { UnitDefinition } from './types';

// Based on the "Book Map" from the provided PDF (Pages 5-7)
export const UNITS: UnitDefinition[] = [
  {
    id: 1,
    title: "Unit 1: A Long and Healthy Life",
    topic: "Health and fitness, healthy habits",
    vocabularyFocus: "Words related to health, fitness, bacteria, viruses",
    grammarFocus: "Past simple vs. Present perfect, Strong and weak forms of auxiliary verbs"
  },
  {
    id: 2,
    title: "Unit 2: The Generation Gap",
    topic: "Generational differences, family conflicts",
    vocabularyFocus: "Words related to generational differences, family types",
    grammarFocus: "Modal verbs: must, have to, should; Contracted forms"
  },
  {
    id: 3,
    title: "Unit 3: Cities of the Future",
    topic: "Smart living, urban infrastructure",
    vocabularyFocus: "Words related to cities and smart living",
    grammarFocus: "Stative verbs in continuous form, Linking verbs"
  },
  {
    id: 4,
    title: "Unit 4: ASEAN and Viet Nam",
    topic: "ASEAN culture, youth programmes",
    vocabularyFocus: "Words related to ASEAN, cultural exchange",
    grammarFocus: "Gerunds as subjects and objects"
  },
  {
    id: 5,
    title: "Unit 5: Global Warming",
    topic: "Environmental impact, black carbon",
    vocabularyFocus: "Words related to global warming, environment",
    grammarFocus: "Present participle and past participle clauses"
  },
  {
    id: 6,
    title: "Unit 6: Preserving Our Heritage",
    topic: "Cultural heritage sites, preservation",
    vocabularyFocus: "Words related to preserving heritage",
    grammarFocus: "To-infinitive clauses"
  },
  {
    id: 7,
    title: "Unit 7: Education Options",
    topic: "Vocational training, higher education",
    vocabularyFocus: "Words related to education after leaving school",
    grammarFocus: "Perfect gerunds and perfect participle clauses"
  },
  {
    id: 8,
    title: "Unit 8: Becoming Independent",
    topic: "Teen independence, life skills",
    vocabularyFocus: "Words related to teen independence, time management",
    grammarFocus: "Cleft sentences with It is/was... that/who..."
  },
  {
    id: 9,
    title: "Unit 9: Social Issues",
    topic: "Peer pressure, bullying, social awareness",
    vocabularyFocus: "Words related to social issues",
    grammarFocus: "Linking words and phrases"
  },
  {
    id: 10,
    title: "Unit 10: The Ecosystem",
    topic: "Flora and fauna, biodiversity",
    vocabularyFocus: "Words related to ecosystems, nature",
    grammarFocus: "Compound nouns"
  }
];