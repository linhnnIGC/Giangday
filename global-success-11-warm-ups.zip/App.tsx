import React, { useState, useEffect } from 'react';
import { UnitSidebar } from './components/UnitSidebar';
import { ActivityCard } from './components/ActivityCard';
import { ApiKeyModal } from './components/ApiKeyModal';
import { UNITS, LESSONS, DEFAULT_ACTIVITY } from './constants';
import { Unit, LessonType, Activity } from './types';
import { generateWarmUp } from './services/geminiService';
import { Menu, Wand2, BookOpenCheck } from 'lucide-react';

const App: React.FC = () => {
  const [apiKey, setApiKey] = useState<string>('');
  const [showKeyModal, setShowKeyModal] = useState(true);
  
  const [selectedUnit, setSelectedUnit] = useState<Unit>(UNITS[0]);
  const [selectedLesson, setSelectedLesson] = useState<LessonType>(LESSONS[0]);
  
  const [currentActivity, setCurrentActivity] = useState<Activity | null>(DEFAULT_ACTIVITY);
  const [isLoading, setIsLoading] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [cache, setCache] = useState<Record<string, Activity>>({
    "1-Getting Started": DEFAULT_ACTIVITY
  });

  // Load API key from session storage if available
  useEffect(() => {
    const storedKey = sessionStorage.getItem('gemini_api_key');
    if (storedKey) {
      setApiKey(storedKey);
      setShowKeyModal(false);
    }
  }, []);

  const handleSaveKey = (key: string) => {
    setApiKey(key);
    sessionStorage.setItem('gemini_api_key', key);
    setShowKeyModal(false);
  };

  const fetchActivity = async (unit: Unit, lesson: LessonType) => {
    const cacheKey = `${unit.id}-${lesson}`;
    
    // Use cache if available
    if (cache[cacheKey]) {
      setCurrentActivity(cache[cacheKey]);
      return;
    }

    setIsLoading(true);
    setCurrentActivity(null);

    try {
      const activity = await generateWarmUp(apiKey, unit, lesson);
      if (activity) {
        setCache(prev => ({ ...prev, [cacheKey]: activity }));
        setCurrentActivity(activity);
      } else {
        // Fallback error state logic could go here
        console.error("No activity generated");
      }
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  // Trigger fetch when selection changes
  useEffect(() => {
    if (apiKey) {
      fetchActivity(selectedUnit, selectedLesson);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedUnit, selectedLesson, apiKey]);

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50">
      <ApiKeyModal isOpen={showKeyModal} onSave={handleSaveKey} />

      <UnitSidebar 
        units={UNITS} 
        selectedUnit={selectedUnit} 
        onSelectUnit={setSelectedUnit}
        isOpen={sidebarOpen}
        setIsOpen={setSidebarOpen}
      />

      <main className="flex-1 flex flex-col h-full overflow-hidden relative">
        {/* Top Navigation Bar */}
        <header className="bg-white border-b border-slate-200 shadow-sm z-10">
          <div className="flex items-center justify-between p-4">
            <div className="flex items-center gap-3">
              <button 
                className="md:hidden p-2 text-slate-600 hover:bg-slate-100 rounded-lg"
                onClick={() => setSidebarOpen(true)}
              >
                <Menu size={24} />
              </button>
              <div>
                <div className="text-xs font-bold text-teal-600 uppercase tracking-widest mb-1">Unit {selectedUnit.id}</div>
                <h2 className="text-lg md:text-xl font-bold text-slate-800 leading-none truncate max-w-[200px] md:max-w-md">
                  {selectedUnit.title}
                </h2>
              </div>
            </div>
            
            <button 
               onClick={() => fetchActivity(selectedUnit, selectedLesson)}
               disabled={isLoading}
               className="flex items-center gap-2 bg-teal-50 text-teal-700 px-4 py-2 rounded-lg hover:bg-teal-100 transition-colors border border-teal-200 text-sm font-medium"
            >
              <Wand2 size={16} />
              <span className="hidden md:inline">Regenerate</span>
            </button>
          </div>

          {/* Lesson Tabs */}
          <div className="flex overflow-x-auto scrollbar-hide border-t border-slate-100">
            {LESSONS.map((lesson) => (
              <button
                key={lesson}
                onClick={() => setSelectedLesson(lesson)}
                className={`
                  flex-shrink-0 px-5 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap
                  ${selectedLesson === lesson 
                    ? 'border-teal-600 text-teal-700 bg-teal-50/50' 
                    : 'border-transparent text-slate-500 hover:text-teal-600 hover:bg-slate-50'}
                `}
              >
                {lesson}
              </button>
            ))}
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-4 md:p-8">
          <div className="max-w-4xl mx-auto">
            {/* Context Header */}
            <div className="flex items-center justify-between mb-6">
               <div className="flex items-center gap-2 text-slate-500 text-sm">
                  <BookOpenCheck size={16} />
                  <span>Global Success 11 &gt; Unit {selectedUnit.id} &gt; {selectedLesson}</span>
               </div>
            </div>

            {currentActivity || isLoading ? (
              <ActivityCard activity={currentActivity!} isLoading={isLoading} />
            ) : (
               <div className="text-center py-20">
                 <p className="text-slate-400">Select a lesson to generate a warm-up activity.</p>
               </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;