import React from 'react';
import { Activity } from '../types';
import { Clock, Users, Target, ListChecks, Lightbulb } from 'lucide-react';

interface Props {
  activity: Activity;
  isLoading: boolean;
}

export const ActivityCard: React.FC<Props> = ({ activity, isLoading }) => {
  if (isLoading) {
    return (
      <div className="w-full h-96 flex flex-col items-center justify-center space-y-4 animate-pulse">
        <div className="w-16 h-16 border-4 border-teal-500 border-t-transparent rounded-full animate-spin"></div>
        <p className="text-teal-800 font-medium text-lg">Designing the perfect activity...</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-lg border border-teal-100 overflow-hidden">
      {/* Header */}
      <div className="bg-teal-600 p-6 text-white">
        <h2 className="text-3xl font-bold mb-2">{activity.title}</h2>
        <div className="flex flex-wrap gap-4 text-teal-50">
          <div className="flex items-center gap-2 bg-teal-700/50 px-3 py-1 rounded-full text-sm">
            <Clock size={18} />
            <span>{activity.time}</span>
          </div>
          <div className="flex items-center gap-2 bg-teal-700/50 px-3 py-1 rounded-full text-sm">
            <Users size={18} />
            <span>{activity.type}</span>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-6 space-y-8">
        {/* Objective */}
        <section>
          <div className="flex items-center gap-2 mb-3 text-teal-700 font-bold text-lg uppercase tracking-wide">
            <Target size={20} />
            <h3>Objective & Connection</h3>
          </div>
          <div className="bg-teal-50 p-4 rounded-lg border-l-4 border-teal-500 text-slate-700 leading-relaxed">
            {activity.objective}
          </div>
        </section>

        {/* Preparation & Steps */}
        <div className="grid md:grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1">
            <div className="flex items-center gap-2 mb-3 text-teal-700 font-bold text-lg uppercase tracking-wide">
              <ListChecks size={20} />
              <h3>Preparation</h3>
            </div>
            <ul className="space-y-2">
              {activity.preparation.length > 0 ? (
                activity.preparation.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-3 text-slate-600">
                    <span className="w-2 h-2 mt-2 bg-teal-400 rounded-full shrink-0" />
                    <span>{item}</span>
                  </li>
                ))
              ) : (
                <li className="text-slate-500 italic">No special materials needed.</li>
              )}
            </ul>
          </div>

          <div className="lg:col-span-2">
            <div className="flex items-center gap-2 mb-3 text-teal-700 font-bold text-lg uppercase tracking-wide">
              <ListChecks size={20} />
              <h3>Procedure</h3>
            </div>
            <ol className="space-y-4">
              {activity.steps.map((step, idx) => (
                <li key={idx} className="flex gap-4">
                  <div className="flex-shrink-0 w-8 h-8 rounded-full bg-teal-100 text-teal-700 flex items-center justify-center font-bold">
                    {idx + 1}
                  </div>
                  <p className="text-slate-700 mt-1">{step}</p>
                </li>
              ))}
            </ol>
          </div>
        </div>

        {/* Teacher Tips */}
        <section className="bg-amber-50 rounded-lg p-5 border border-amber-200">
          <div className="flex items-center gap-2 mb-2 text-amber-700 font-bold text-lg">
            <Lightbulb size={20} />
            <h3>Teacher's Tip for Large Classes</h3>
          </div>
          <p className="text-amber-900 italic">
            "{activity.tips}"
          </p>
        </section>
      </div>
    </div>
  );
};