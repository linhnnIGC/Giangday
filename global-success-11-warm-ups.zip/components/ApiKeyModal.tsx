import React, { useState } from 'react';
import { Key, Lock, AlertCircle } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onSave: (key: string) => void;
}

export const ApiKeyModal: React.FC<Props> = ({ isOpen, onSave }) => {
  const [inputKey, setInputKey] = useState('');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputKey.trim()) {
      setError('Please enter a valid API key');
      return;
    }
    onSave(inputKey);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden">
        <div className="bg-teal-600 p-6 text-center">
          <div className="mx-auto bg-white/20 w-16 h-16 rounded-full flex items-center justify-center mb-4">
            <Lock className="text-white" size={32} />
          </div>
          <h2 className="text-2xl font-bold text-white">Teacher Verification</h2>
          <p className="text-teal-100 mt-2 text-sm">To generate unlimited tailored lesson plans, please enter your Gemini API Key.</p>
        </div>
        
        <form onSubmit={handleSubmit} className="p-8">
          <div className="mb-6">
            <label className="block text-sm font-medium text-slate-700 mb-2">Google Gemini API Key</label>
            <div className="relative">
              <Key className="absolute left-3 top-3 text-slate-400" size={18} />
              <input 
                type="password" 
                value={inputKey}
                onChange={(e) => {
                  setInputKey(e.target.value);
                  setError('');
                }}
                className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none transition-all"
                placeholder="AIzaSy..."
              />
            </div>
            {error && (
              <div className="flex items-center gap-1 mt-2 text-red-500 text-xs">
                <AlertCircle size={12} />
                <span>{error}</span>
              </div>
            )}
            <p className="text-xs text-slate-500 mt-2">
              Don't have one? <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noreferrer" className="text-teal-600 underline">Get it here for free</a>.
            </p>
          </div>

          <button 
            type="submit"
            className="w-full bg-teal-600 hover:bg-teal-700 text-white font-semibold py-3 px-4 rounded-xl transition-colors shadow-lg shadow-teal-600/30"
          >
            Access Classroom Resources
          </button>
        </form>
      </div>
    </div>
  );
};