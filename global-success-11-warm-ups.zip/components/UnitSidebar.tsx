import React from 'react';
import { Unit } from '../types';
import { BookOpen, ChevronRight } from 'lucide-react';

interface Props {
  units: Unit[];
  selectedUnit: Unit;
  onSelectUnit: (unit: Unit) => void;
  isOpen: boolean;
  setIsOpen: (val: boolean) => void;
}

export const UnitSidebar: React.FC<Props> = ({ units, selectedUnit, onSelectUnit, isOpen, setIsOpen }) => {
  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-20 md:hidden"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Sidebar Container */}
      <aside 
        className={`
          fixed top-0 left-0 z-30 h-full w-72 bg-teal-900 text-white transition-transform duration-300 ease-in-out
          ${isOpen ? 'translate-x-0' : '-translate-x-full'}
          md:translate-x-0 md:static md:h-screen flex flex-col shadow-2xl
        `}
      >
        <div className="p-6 border-b border-teal-800">
          <h1 className="text-xl font-bold flex items-center gap-2">
            <BookOpen className="text-teal-400" />
            Global Success 11
          </h1>
          <p className="text-teal-400 text-xs mt-1 uppercase tracking-wider">Warm-up Resource</p>
        </div>

        <nav className="flex-1 overflow-y-auto py-4 scrollbar-hide">
          <div className="px-4 mb-2 text-xs font-semibold text-teal-500 uppercase">Select Unit</div>
          <ul className="space-y-1 px-2">
            {units.map((unit) => (
              <li key={unit.id}>
                <button
                  onClick={() => {
                    onSelectUnit(unit);
                    setIsOpen(false);
                  }}
                  className={`
                    w-full text-left px-4 py-3 rounded-lg flex items-center justify-between group transition-colors
                    ${selectedUnit.id === unit.id 
                      ? 'bg-teal-700 text-white shadow-md' 
                      : 'text-teal-200 hover:bg-teal-800 hover:text-white'}
                  `}
                >
                  <div className="flex flex-col">
                    <span className="text-xs font-bold opacity-70">Unit {unit.id}</span>
                    <span className="text-sm font-medium truncate w-48">{unit.title}</span>
                  </div>
                  {selectedUnit.id === unit.id && <ChevronRight size={16} />}
                </button>
              </li>
            ))}
          </ul>
        </nav>

        <div className="p-4 border-t border-teal-800 bg-teal-950/50 text-xs text-teal-400 text-center">
          Designed for 40-student classes
        </div>
      </aside>
    </>
  );
};