import { Unit, LessonType, Activity } from './types';

export const UNITS: Unit[] = [
  { id: 1, title: "A Long and Healthy Life", theme: "Our Lives" },
  { id: 2, title: "The Generation Gap", theme: "Our Lives" },
  { id: 3, title: "Cities of the Future", theme: "Our Future" },
  { id: 4, title: "ASEAN and Viet Nam", theme: "Our Society" },
  { id: 5, title: "Global Warming", theme: "Our Environment" },
  { id: 6, title: "Preserving Our Heritage", theme: "Our Society" },
  { id: 7, title: "Education Options for School-Leavers", theme: "Our Future" },
  { id: 8, title: "Becoming Independent", theme: "Our Lives" },
  { id: 9, title: "Social Issues", theme: "Our Society" },
  { id: 10, title: "The Ecosystem", theme: "Our Environment" },
];

export const LESSONS: LessonType[] = [
  "Getting Started",
  "Language",
  "Reading",
  "Speaking",
  "Listening",
  "Writing",
  "Communication & Culture / CLIL",
  "Looking Back & Project"
];

// Pre-filled example for Unit 1, Lesson 1 to show immediate value
export const DEFAULT_ACTIVITY: Activity = {
  title: "Health Hero Relay",
  time: "5 minutes",
  type: "Group Competition (4 groups)",
  objective: "Activate prior vocabulary related to daily routines and health to prepare for 'A Long and Healthy Life'.",
  preparation: [
    "Board divided into 4 columns.",
    "4 markers."
  ],
  steps: [
    "Divide the class into 4 groups (based on their seating rows).",
    "On the board, write the heading 'Healthy Habits' for each column.",
    "One student from each group runs to the board, writes one healthy habit (e.g., 'exercise', 'eat fruit'), and runs back to hand the marker to the next person.",
    "Groups have 3 minutes to list as many as possible.",
    "Teacher quickly reviews unique words. The group with the most correct words wins."
  ],
  tips: "Since the room is small, have students pass the marker paper-relay style instead of running if space is too tight. Ensure aisles are clear."
};