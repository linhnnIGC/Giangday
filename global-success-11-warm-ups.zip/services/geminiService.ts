import { GoogleGenAI } from "@google/genai";
import { Unit, LessonType, Activity } from "../types";

const SYSTEM_INSTRUCTION = `
You are an expert English teacher (ESL/EFL) designing lesson plans for the "Global Success 11" textbook (Grade 11 in Vietnam).
Your task is to create a SINGLE warm-up activity for a specific lesson.

Constraints & Context:
1. Class Size: 40 students.
2. Grouping: 4 large groups (rows/tables) or Pair work.
3. Space: Small classroom, limited movement. High-energy but controlled activities preferred.
4. Time Limit: STRICTLY 5 minutes maximum.
5. Content:
   - Must connect relevant previous knowledge to the new lesson topic.
   - Must be engaging and diverse (games, quizzes, brainstorming, role-play).
   - Instructions must be crystal clear.

Input: Unit Title, Lesson Type.
Output: A JSON object with the following schema:
{
  "title": "Name of activity",
  "time": "5 minutes",
  "type": "Type of interaction (e.g. Group Work)",
  "objective": "How it connects old and new knowledge",
  "preparation": ["List of materials or board prep"],
  "steps": ["Step 1", "Step 2", "Step 3", "Step 4"],
  "tips": "Specific management advice for 40 students in a small room"
}
Do not wrap the JSON in markdown code blocks. Return raw JSON only.
`;

export const generateWarmUp = async (
  apiKey: string,
  unit: Unit,
  lesson: LessonType
): Promise<Activity | null> => {
  if (!apiKey) return null;

  const prompt = `
  Create a warm-up activity for:
  Textbook: Global Success 11
  Unit ${unit.id}: ${unit.title}
  Lesson: ${lesson}

  Context: 40 students, small room.
  `;

  try {
    const ai = new GoogleGenAI({ apiKey });
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        responseMimeType: "application/json"
      }
    });

    const text = response.text;
    if (!text) return null;

    try {
      const activity = JSON.parse(text) as Activity;
      return activity;
    } catch (e) {
      console.error("Failed to parse JSON", e);
      return null;
    }
  } catch (error) {
    console.error("Gemini API Error", error);
    throw error;
  }
};