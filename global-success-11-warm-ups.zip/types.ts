export interface Unit {
  id: number;
  title: string;
  theme: string;
}

export type LessonType = 
  | "Getting Started"
  | "Language"
  | "Reading"
  | "Speaking"
  | "Listening"
  | "Writing"
  | "Communication & Culture / CLIL"
  | "Looking Back & Project";

export interface Activity {
  title: string;
  time: string; // e.g., "5 minutes"
  type: string; // e.g., "Group Work", "Mingle", "Game"
  objective: string; // Connection between old and new lesson
  preparation: string[];
  steps: string[];
  tips: string; // Specific advice for 40 students/small room
}

export interface GeneratedContent {
  [key: string]: Activity; // Key format: "unitId-lessonIndex"
}