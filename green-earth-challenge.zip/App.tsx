import React, { useState, useEffect, useRef } from 'react';
import { GameState, Question } from './types';
import { QUIZ_DATA } from './constants';
import { generateTeacherIntro, generateFeedback, generateFinalSummary } from './services/geminiService';
import TeacherAvatar from './components/TeacherAvatar';
import QuizCard from './components/QuizCard';
import GameControls from './components/GameControls';
import LoadingDots from './components/LoadingDots';

// Fisher-Yates shuffle algorithm
const shuffleArray = (array: Question[]) => {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
};

const App: React.FC = () => {
  // Initialize questions with a shuffled version of the data
  const [questions, setQuestions] = useState<Question[]>(() => shuffleArray(QUIZ_DATA));
  const [gameState, setGameState] = useState<GameState>(GameState.INTRO);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [teacherMessage, setTeacherMessage] = useState<string>("");
  const [isTyping, setIsTyping] = useState(false);
  const [hasStarted, setHasStarted] = useState(false);
  
  const bottomRef = useRef<HTMLDivElement>(null);

  // Initialize the intro
  useEffect(() => {
    const fetchIntro = async () => {
      setIsTyping(true);
      const intro = await generateTeacherIntro();
      setTeacherMessage(intro);
      setIsTyping(false);
    };
    fetchIntro();
  }, []);

  // Scroll to bottom when content changes (useful on mobile)
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [teacherMessage, gameState, currentQuestionIndex]);

  const handleStartGame = () => {
    setHasStarted(true);
    setGameState(GameState.PLAYING);
    setTeacherMessage("Câu hỏi đầu tiên! Chúc may mắn!");
  };

  const handleSelectAnswer = async (key: string) => {
    if (gameState !== GameState.PLAYING) return;

    setSelectedAnswer(key);
    setGameState(GameState.FEEDBACK);
    setIsTyping(true);

    const currentQuestion = questions[currentQuestionIndex];
    const isCorrect = key === currentQuestion.correctAnswer;

    if (isCorrect) {
      setScore(prev => prev + 1);
    }

    // Call Gemini for personality-driven feedback
    const feedback = await generateFeedback(currentQuestion, key, isCorrect);
    setTeacherMessage(feedback);
    setIsTyping(false);
  };

  const handleNextQuestion = async () => {
    const nextIndex = currentQuestionIndex + 1;

    if (nextIndex < questions.length) {
      setCurrentQuestionIndex(nextIndex);
      setSelectedAnswer(null);
      setGameState(GameState.PLAYING);
      setTeacherMessage("Tiếp tục nào..."); // Placeholder while user reads Q
    } else {
      setGameState(GameState.FINISHED);
      setIsTyping(true);
      const summary = await generateFinalSummary(score, questions.length);
      setTeacherMessage(summary);
      setIsTyping(false);
    }
  };

  const handleRestart = () => {
    setScore(0);
    setCurrentQuestionIndex(0);
    setSelectedAnswer(null);
    setGameState(GameState.PLAYING);
    setQuestions(shuffleArray(QUIZ_DATA)); // Reshuffle on restart
    setTeacherMessage("Lần này hãy cố gắng đạt điểm tối đa nhé!");
  };

  const currentQuestion = questions[currentQuestionIndex];
  const progressPercentage = ((currentQuestionIndex) / questions.length) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 text-gray-800 font-sans selection:bg-green-200">
      <div className="max-w-4xl mx-auto px-4 py-6 md:py-12 min-h-screen flex flex-col">
        
        {/* Header / Progress */}
        {hasStarted && gameState !== GameState.FINISHED && (
          <div className="mb-8 fade-in">
             <div className="flex justify-between items-end mb-2">
                <h1 className="text-xl font-bold text-green-800">Green Earth Challenge</h1>
                <span className="text-sm font-semibold text-gray-500">Score: {score}/{questions.length}</span>
             </div>
             <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div 
                  className="bg-green-600 h-2.5 rounded-full transition-all duration-500 ease-out" 
                  style={{ width: `${progressPercentage}%` }}
                ></div>
             </div>
          </div>
        )}

        {/* Main Interaction Area */}
        <div className="flex-grow flex flex-col md:flex-row gap-6 items-start">
          
          {/* Teacher Section */}
          <div className="md:w-1/3 w-full flex flex-col items-center md:sticky md:top-8 z-10">
            <TeacherAvatar expression={isTyping ? 'thinking' : (gameState === GameState.FEEDBACK && selectedAnswer === currentQuestion?.correctAnswer ? 'happy' : 'neutral')} />
            
            {/* Chat Bubble */}
            <div className="mt-4 bg-white border border-green-200 p-4 rounded-2xl rounded-tl-none shadow-md w-full relative">
               <div className="absolute -top-2 left-4 w-4 h-4 bg-white border-l border-t border-green-200 transform rotate-45"></div>
               <div className="text-gray-700 leading-relaxed min-h-[60px] flex items-center">
                 {isTyping ? <LoadingDots /> : teacherMessage}
               </div>
            </div>
          </div>

          {/* Game Stage Content */}
          <div className="md:w-2/3 w-full flex flex-col">
            
            {!hasStarted && (
              <div className="bg-white p-8 rounded-2xl shadow-xl text-center fade-in border-t-8 border-green-500">
                <h1 className="text-3xl font-extrabold text-green-800 mb-4">Green Earth Challenge</h1>
                <p className="text-gray-600 mb-8">
                  Kiểm tra kiến thức ngữ pháp của bạn về "Participle Clauses" và học thêm về môi trường!
                </p>
                <button 
                  onClick={handleStartGame}
                  className="bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-8 rounded-full shadow-lg transition transform hover:scale-105"
                >
                  Bắt đầu ngay
                </button>
              </div>
            )}

            {hasStarted && gameState !== GameState.FINISHED && currentQuestion && (
              <>
                <QuizCard 
                  question={currentQuestion}
                  selectedAnswer={selectedAnswer}
                  onSelectAnswer={handleSelectAnswer}
                  isLocked={gameState === GameState.FEEDBACK}
                />
                
                <GameControls 
                  onNext={handleNextQuestion}
                  showNext={gameState === GameState.FEEDBACK && !isTyping}
                  disabled={isTyping}
                />
              </>
            )}

            {gameState === GameState.FINISHED && (
              <div className="bg-white p-8 rounded-2xl shadow-xl text-center fade-in border-t-8 border-green-500">
                <div className="mb-6">
                  <span className="text-6xl">🌍</span>
                </div>
                <h2 className="text-3xl font-bold text-gray-800 mb-2">Hoàn thành!</h2>
                <div className="text-5xl font-black text-green-600 mb-4">{score} / {questions.length}</div>
                <p className="text-gray-600 mb-8">
                  Cảm ơn bạn đã tham gia bảo vệ trái đất xanh thông qua kiến thức ngữ pháp!
                </p>
                <button 
                  onClick={handleRestart}
                  className="bg-white border-2 border-green-600 text-green-600 font-bold py-3 px-8 rounded-full hover:bg-green-50 transition"
                >
                  Chơi lại
                </button>
              </div>
            )}
          </div>

        </div>
        <div ref={bottomRef} className="h-4"></div>
      </div>
    </div>
  );
};

export default App;