import React from 'react';

interface GameControlsProps {
  onNext: () => void;
  showNext: boolean;
  disabled: boolean;
}

const GameControls: React.FC<GameControlsProps> = ({ onNext, showNext, disabled }) => {
  if (!showNext) return null;

  return (
    <div className="mt-8 flex justify-center fade-in">
      <button
        onClick={onNext}
        disabled={disabled}
        className="bg-green-600 hover:bg-green-700 text-white text-lg font-bold py-3 px-10 rounded-full shadow-lg transform transition hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
      >
        <span>Next Question</span>
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
          <path fillRule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clipRule="evenodd" />
        </svg>
      </button>
    </div>
  );
};

export default GameControls;