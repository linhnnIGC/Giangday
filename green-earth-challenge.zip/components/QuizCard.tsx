import React from 'react';
import { Question } from '../types';

interface QuizCardProps {
  question: Question;
  selectedAnswer: string | null;
  onSelectAnswer: (key: string) => void;
  isLocked: boolean;
}

const QuizCard: React.FC<QuizCardProps> = ({ question, selectedAnswer, onSelectAnswer, isLocked }) => {
  return (
    <div className="w-full max-w-2xl bg-white rounded-2xl shadow-xl p-6 md:p-8 border-t-8 border-green-500 fade-in">
      <div className="mb-6">
        <span className="inline-block bg-green-100 text-green-800 text-xs font-bold px-3 py-1 rounded-full mb-2">
          Question {question.id}
        </span>
        <h2 className="text-xl md:text-2xl font-bold text-gray-800 leading-relaxed">
          {question.text}
        </h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {question.options.map((option) => {
          const isSelected = selectedAnswer === option.key;
          let buttonStyle = "border-2 border-gray-200 bg-gray-50 hover:bg-green-50 hover:border-green-300 text-gray-700";

          if (isSelected) {
            buttonStyle = "border-2 border-green-600 bg-green-100 text-green-900 font-semibold ring-2 ring-green-200";
          }
          
          if (isLocked && !isSelected) {
             buttonStyle = "border-gray-100 bg-gray-50 text-gray-400 cursor-not-allowed opacity-60";
          }

          return (
            <button
              key={option.key}
              onClick={() => !isLocked && onSelectAnswer(option.key)}
              disabled={isLocked}
              className={`p-4 rounded-xl text-left transition-all duration-200 flex items-center ${buttonStyle}`}
            >
              <span className={`w-8 h-8 rounded-full flex items-center justify-center mr-3 text-sm font-bold ${isSelected ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-600'}`}>
                {option.key}
              </span>
              <span className="text-lg">{option.value}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default QuizCard;