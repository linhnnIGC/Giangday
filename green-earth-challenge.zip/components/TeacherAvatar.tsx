import React from 'react';

interface TeacherAvatarProps {
  expression: 'neutral' | 'happy' | 'thinking';
}

const TeacherAvatar: React.FC<TeacherAvatarProps> = ({ expression }) => {
  // Replace the src below with your actual image file path or import
  // e.g., import teacherImg from '../assets/thaylinh.jpg';
  // For now, using a placeholder that resembles the description (Asian male, glasses)
  const imageUrl = "https://img.freepik.com/free-photo/portrait-smiling-asian-businessman-glasses_171337-4849.jpg?w=360&t=st=1709400000~exp=1709400600~hmac=placeholder"; 
  
  return (
    <div className="relative w-28 h-28 md:w-36 md:h-36 flex-shrink-0 mx-auto md:mx-0 group">
      <div className={`absolute inset-0 bg-white rounded-full border-4 border-blue-500 overflow-hidden shadow-lg transition-transform duration-300 ${expression === 'happy' ? 'scale-105 ring-4 ring-blue-200' : ''}`}>
        <img 
          src={imageUrl} 
          alt="Thầy Linh" 
          className="w-full h-full object-cover"
        />
      </div>
      
      {/* Expression Overlay (Subtle) */}
      {expression === 'thinking' && (
         <div className="absolute top-0 right-0 bg-white rounded-full p-1 shadow-md border border-gray-200">
           <span className="text-xl">🤔</span>
         </div>
      )}
      
      {/* Badge */}
      <div className="absolute -bottom-2 -right-2 bg-blue-600 text-white text-xs font-bold px-3 py-1 rounded-full shadow border border-blue-400">
        Thầy Linh
      </div>
    </div>
  );
};

export default TeacherAvatar;