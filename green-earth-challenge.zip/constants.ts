import { Question, TeacherPersonality } from './types';

export const TEACHER_PERSONA: TeacherPersonality = {
  name: "Thầy Linh",
  role: "Giáo viên Tiếng Anh & Người dẫn chương trình",
  tone: "Chuyên nghiệp, tâm huyết, truyền cảm hứng và thân thiện."
};

export const QUIZ_DATA: Question[] = [
  {
    id: 1,
    text: "______ by the heavy storm, the old tree fell onto the school roof.",
    options: [
      { key: "A", value: "Damaging" },
      { key: "B", value: "Damaged" },
      { key: "C", value: "To damage" },
      { key: "D", value: "Damage" }
    ],
    correctAnswer: "B",
    explanation: "Câu bị động (Passive Voice) - Cây bị hư hại bởi cơn bão, nên ta dùng V-ed (Past Participle)."
  },
  {
    id: 2,
    text: "______ that air pollution is a serious problem, the government passed new laws.",
    options: [
      { key: "A", value: "Realized" },
      { key: "B", value: "To realize" },
      { key: "C", value: "Realizing" },
      { key: "D", value: "Realize" }
    ],
    correctAnswer: "C",
    explanation: "Câu chủ động (Active Voice) - Chính phủ nhận ra vấn đề, cùng chủ ngữ, dùng V-ing (Present Participle)."
  },
  {
    id: 3,
    text: "______ in the city center, the park is a popular place for people to relax.",
    options: [
      { key: "A", value: "Locating" },
      { key: "B", value: "Located" },
      { key: "C", value: "To locate" },
      { key: "D", value: "Location" }
    ],
    correctAnswer: "B",
    explanation: "Rút gọn câu bị động - Công viên được đặt tại vị trí (It is located...), dùng V-ed."
  },
  {
    id: 4,
    text: "______ too much electricity, old appliances should be replaced with energy-saving ones.",
    options: [
      { key: "A", value: "Consume" },
      { key: "B", value: "Consumed" },
      { key: "C", value: "Consuming" },
      { key: "D", value: "To consume" }
    ],
    correctAnswer: "C",
    explanation: "Câu chủ động - Thiết bị cũ tiêu thụ điện (Old appliances consume...), rút gọn dùng V-ing."
  },
  {
    id: 5,
    text: "______ about the negative effects of tourism, the locals decided to limit visitor numbers.",
    options: [
      { key: "A", value: "Worrying" },
      { key: "B", value: "Worried" },
      { key: "C", value: "Worry" },
      { key: "D", value: "To worry" }
    ],
    correctAnswer: "B",
    explanation: "Tính từ cảm xúc/Bị động (Worried about something) - Người dân lo lắng."
  },
  {
    id: 6,
    text: "If ______ properly, glass bottles can be reused many times.",
    options: [
      { key: "A", value: "cleaned" },
      { key: "B", value: "cleaning" },
      { key: "C", value: "to clean" },
      { key: "D", value: "clean" }
    ],
    correctAnswer: "A",
    explanation: "Rút gọn mệnh đề sau 'If' (dạng bị động) - Nếu chúng được làm sạch (If they are cleaned)."
  },
  {
    id: 7,
    text: "______ trees in the garden, the children found a bird's nest.",
    options: [
      { key: "A", value: "Plant" },
      { key: "B", value: "Planted" },
      { key: "C", value: "Planting" },
      { key: "D", value: "To plant" }
    ],
    correctAnswer: "C",
    explanation: "Câu chủ động - Trong khi đang trồng cây (While planting...), trẻ em tìm thấy tổ chim."
  },
  {
    id: 8,
    text: "______ of plastic, these bags take hundreds of years to decompose.",
    options: [
      { key: "A", value: "Making" },
      { key: "B", value: "To make" },
      { key: "C", value: "Made" },
      { key: "D", value: "Make" }
    ],
    correctAnswer: "C",
    explanation: "Câu bị động - Những cái túi được làm từ nhựa (Made of plastic), dùng V-ed."
  },
  {
    id: 9,
    text: "______ to reduce their carbon footprint, the family started cycling to work.",
    options: [
      { key: "A", value: "Hoped" },
      { key: "B", value: "Hoping" },
      { key: "C", value: "Hope" },
      { key: "D", value: "To hope" }
    ],
    correctAnswer: "B",
    explanation: "Câu chủ động - Gia đình hy vọng (Hoping to...), dùng V-ing để chỉ lý do/nguyên nhân."
  },
  {
    id: 10,
    text: "______ severely by the forest fire, the area needs time to recover.",
    options: [
      { key: "A", value: "Affected" },
      { key: "B", value: "Affecting" },
      { key: "C", value: "Affect" },
      { key: "D", value: "To affect" }
    ],
    correctAnswer: "A",
    explanation: "Câu bị động - Khu vực bị ảnh hưởng nghiêm trọng (It was affected...), dùng V-ed."
  },
  {
    id: 11,
    text: "______ in a fishing net, the dolphin couldn't escape.",
    options: [
      { key: "A", value: "Catching" },
      { key: "B", value: "Caught" },
      { key: "C", value: "Catch" },
      { key: "D", value: "To catch" }
    ],
    correctAnswer: "B",
    explanation: "Câu bị động - Cá heo bị mắc kẹt (Caught in...), dùng V-ed (Past Participle)."
  },
  {
    id: 12,
    text: "______ renewable energy sources, we can reduce our dependence on fossil fuels.",
    options: [
      { key: "A", value: "Developed" },
      { key: "B", value: "Developing" },
      { key: "C", value: "Develop" },
      { key: "D", value: "To develop" }
    ],
    correctAnswer: "B",
    explanation: "Câu chủ động - Bằng cách phát triển năng lượng (Developing...), dùng V-ing."
  },
  {
    id: 13,
    text: "The documentary ______ on TV last night raised awareness about climate change.",
    options: [
      { key: "A", value: "shown" },
      { key: "B", value: "showing" },
      { key: "C", value: "show" },
      { key: "D", value: "to show" }
    ],
    correctAnswer: "A",
    explanation: "Rút gọn mệnh đề quan hệ bị động - Bộ phim được chiếu (Which was shown...), dùng V-ed."
  },
  {
    id: 14,
    text: "______ by the noise of the construction site, the birds left their nests.",
    options: [
      { key: "A", value: "Frightening" },
      { key: "B", value: "Frightened" },
      { key: "C", value: "Frighten" },
      { key: "D", value: "To frighten" }
    ],
    correctAnswer: "B",
    explanation: "Tính từ cảm xúc/Bị động - Chim bị hoảng sợ bởi tiếng ồn, dùng V-ed."
  },
  {
    id: 15,
    text: "______ to save water, he turns off the tap while brushing his teeth.",
    options: [
      { key: "A", value: "Trying" },
      { key: "B", value: "Tried" },
      { key: "C", value: "Try" },
      { key: "D", value: "To try" }
    ],
    correctAnswer: "A",
    explanation: "Câu chủ động - Cố gắng tiết kiệm nước (Trying to...), dùng V-ing."
  },
  {
    id: 16,
    text: "The waste ______ into the river killed many fish.",
    options: [
      { key: "A", value: "dumping" },
      { key: "B", value: "dumped" },
      { key: "C", value: "dump" },
      { key: "D", value: "to dump" }
    ],
    correctAnswer: "B",
    explanation: "Rút gọn mệnh đề quan hệ bị động - Chất thải bị đổ xuống sông (Which was dumped...), dùng V-ed."
  },
  {
    id: 17,
    text: "______ the danger of rising sea levels, the government built a sea wall.",
    options: [
      { key: "A", value: "Recognized" },
      { key: "B", value: "Recognizing" },
      { key: "C", value: "Recognize" },
      { key: "D", value: "To recognize" }
    ],
    correctAnswer: "B",
    explanation: "Câu chủ động - Chính phủ nhận ra sự nguy hiểm (Recognizing...), dùng V-ing."
  },
  {
    id: 18,
    text: "If ______ carefully, organic waste can be turned into valuable compost.",
    options: [
      { key: "A", value: "managing" },
      { key: "B", value: "managed" },
      { key: "C", value: "manage" },
      { key: "D", value: "to manage" }
    ],
    correctAnswer: "B",
    explanation: "Rút gọn bị động sau 'If' - Nếu được quản lý kỹ (If it is managed...), dùng V-ed."
  },
  {
    id: 19,
    text: "______ no exhaust fumes, electric vehicles help improve air quality.",
    options: [
      { key: "A", value: "Emitting" },
      { key: "B", value: "Emitted" },
      { key: "C", value: "Emit" },
      { key: "D", value: "To emit" }
    ],
    correctAnswer: "A",
    explanation: "Câu chủ động - Xe điện không thải khói (Emitting no fumes...), dùng V-ing."
  },
  {
    id: 20,
    text: "______ with toxic chemicals, the soil became infertile.",
    options: [
      { key: "A", value: "Contaminating" },
      { key: "B", value: "Contaminated" },
      { key: "C", value: "Contaminate" },
      { key: "D", value: "To contaminate" }
    ],
    correctAnswer: "B",
    explanation: "Câu bị động - Đất bị ô nhiễm bởi hóa chất (Contaminated with...), dùng V-ed."
  }
];