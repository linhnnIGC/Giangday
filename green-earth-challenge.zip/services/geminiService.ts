import { GoogleGenAI } from "@google/genai";
import { Question } from '../types';

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

const SYSTEM_INSTRUCTION = `
Bạn là "Thầy Linh", một giáo viên Tiếng Anh và là người dẫn chương trình trò chơi trắc nghiệm tên là "Green Earth Challenge".
Phong cách: Chuyên nghiệp, ấm áp, truyền cảm hứng, và rất tâm huyết với vấn đề môi trường. Giọng văn nam tính, lịch sự.
Nhiệm vụ:
1. Đưa ra phản hồi cho câu trả lời của người chơi về bài tập "Participle Clauses".
2. Giải thích ngắn gọn tại sao đúng hoặc sai (dựa trên ngữ cảnh cung cấp).
3. Luôn giữ chủ đề về môi trường xanh.
4. Ngôn ngữ: Sử dụng tiếng Việt thân mật, tự nhiên.
`;

export const generateTeacherIntro = async (): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: "Hãy chào mừng người chơi đến với 'Green Earth Challenge'! Giới thiệu ngắn gọn (với tư cách là Thầy Linh) rằng hôm nay chúng ta sẽ học về Participle Clauses (V-ing và V-ed) để bảo vệ môi trường. Mời họ bắt đầu câu hỏi số 1. Ngắn gọn dưới 40 từ.",
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
      }
    });
    return response.text || "Xin chào! Thầy là Thầy Linh. Chào mừng đến với Green Earth Challenge.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Chào mừng các bạn đến với Green Earth Challenge cùng Thầy Linh! Hãy cùng bắt đầu nào!";
  }
};

export const generateFeedback = async (
  question: Question,
  userAnswer: string,
  isCorrect: boolean
): Promise<string> => {
  const prompt = `
    Người chơi vừa trả lời câu hỏi sau: "${question.text}"
    Đáp án họ chọn: ${userAnswer}.
    Đáp án đúng là: ${question.correctAnswer}.
    Kết quả: ${isCorrect ? "ĐÚNG" : "SAU"}.
    Giải thích kỹ thuật: ${question.explanation}.

    Hãy đưa ra lời nhận xét của Thầy Linh.
    - Nếu đúng: Chúc mừng một cách hào hứng.
    - Nếu sai: Động viên và giải thích lại nhẹ nhàng.
    - Kết thúc bằng một câu ngắn mời qua câu tiếp theo.
    - Giữ độ dài dưới 50 từ.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
      }
    });
    return response.text || (isCorrect ? "Chính xác! Em làm tốt lắm." : `Chưa đúng rồi. Đáp án là ${question.correctAnswer}.`);
  } catch (error) {
    return isCorrect 
      ? `Tuyệt vời! ${question.explanation}` 
      : `Tiếc quá! Đáp án đúng là ${question.correctAnswer}. ${question.explanation}`;
  }
};

export const generateFinalSummary = async (score: number, total: number): Promise<string> => {
  const prompt = `
    Trò chơi kết thúc.
    Điểm số: ${score}/${total}.
    Hãy đưa ra lời tổng kết của Thầy Linh.
    - Nếu điểm cao (8-10): Khen ngợi và gọi họ là "Đại sứ Môi trường".
    - Nếu điểm trung bình (5-7): Khích lệ sự cố gắng.
    - Nếu điểm thấp: Động viên kiên trì học tập.
    - Ngắn gọn, truyền cảm hứng.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
      }
    });
    return response.text || `Em đã hoàn thành! Điểm số: ${score}/${total}.`;
  } catch (error) {
    return `Chúc mừng em đã hoàn thành bài thi với số điểm ${score}/${total}!`;
  }
};