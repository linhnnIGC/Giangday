export interface Question {
  id: number;
  text: string;
  options: {
    key: string; // 'A', 'B', 'C', 'D'
    value: string;
  }[];
  correctAnswer: string;
  explanation: string;
}

export enum GameState {
  INTRO = 'INTRO',
  PLAYING = 'PLAYING',
  FEEDBACK = 'FEEDBACK',
  FINISHED = 'FINISHED'
}

export interface ChatMessage {
  role: 'teacher' | 'user';
  text: string;
}

export interface TeacherPersonality {
  name: string;
  role: string;
  tone: string;
}